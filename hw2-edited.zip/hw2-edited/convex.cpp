#include <iostream>
// using namespace std;

int main(){
    /*
        Keep your solution for Convex Hull Part in this file!
        Program Compile Command: g++ -std=c++11 -Wall -Werror conve.cpp -o convex
        Program Run Command: ./convex <input.txt>
        Expected input: /cases/case{$n}/input{$n}.txt
        Expected output: convex.txt
        Please, try to write clean and readable code. Remember to comment!!
    */
    exit(0);
}