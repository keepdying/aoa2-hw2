#include <iostream>
// using namespace std;

int main(){
    /*
        Keep your solution for Prim's algorithm Part in this file!
        Program Compile Command: g++ -std=c++11 -Wall -Werror prim.cpp -o prim
        Program Run Command: ./prim <input.txt>
        Expected input: /cases/case{$n}/input{$n}.txt
        Expected output: prim.txt
        Please, try to write clean and readable code. Remember to comment!!
    */
    exit(0);
}